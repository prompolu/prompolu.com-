# PROMPOLU — Une nouvelle perspective

## Reference analysis and evidence
No reference video was supplied. The supplied written brief specifies large editorial typography, continuous geometric transitions, rhythmic electronic sound, real brand assets, and 4K / 60 fps delivery. These are instructions, not observations of a film. No claim is made to reproduce an unseen reference.

## Original art direction
Cream #F1F0EC, ink #15171A, bronze #8C6A45. Anton display type and DM Sans supporting type match the released website. Original PROMPOLU and STRUGAL raster logos retain their proportions and lettering. French copy; no voice-over. Generous margins, exact alignment, restrained shadows. The release itself is the product: show the actual website and its product families rather than make unsupported technical claims.

Assets come from the existing website checkout. Some existing website visuals are illustrative; they are not represented as documentary product photography. The exterior gallery panel uses the existing 1200 × 900 pergola render, explicitly labelled « VISUEL 3D », rather than enlarging a lower-resolution 640-pixel image. No new product pictures are generated for this film. No private AR content or signed-access links are exposed.

## Full film following prototype approval: 20 seconds, 120 BPM / 40 beats
| Time | Beats | Story and text | Motion / camera | Transition and implementation | Sound |
|---|---|---|---|---|---|
| 0–2 | 1–4 | UNE NOUVELLE / PERSPECTIVE. Original dual logos above. | Two staggered masked line reveals; bronze line extends. | Line becomes rounded browser frame; cubic ease-out for text, symmetric ease for frame. | Airy swell, restrained downbeat, two soft clicks. |
| 2–5 | 5–10 | NOTRE NOUVEAU SITE EST EN LIGNE. Actual homepage. | Browser frame expands; screenshot moves within its mask. | Frame scales and shifts into right-hand column; no photographic warping. | Filtered chord opens on the frame reveal; light hats and bass. |
| 5–9 | 11–18 | COULISSANTS / BATTANTS. | Independent cards slide into a two-panel composition; complete window imagery stays recognisable. | Match position of browser/image panel into a gallery; staggered translations and subtle dolly. | Clicks at card landings, short directional sweep. |
| 9–12 | 19–24 | AGENCEMENT / EXTÉRIEUR. | Recompose gallery; feature the existing pergola picture. | Opposed split-panel wipes and typographic mask; no repeated adjacent transition. | Brighter chord and soft metallic accent. |
| 12–16 | 25–32 | VOS GAMMES. VOS PROJETS. / UN NOUVEL ESPACE. Contact/quote flow. | Real UI screenshot moves through a large rounded container. | UI card expands from gallery, then bronze pill grows from its button. | UI ticks; beat accent and low impact at transformation. |
| 16–20 | 33–40 | DÉCOUVREZ LE NOUVEAU SITE. / prompolu.com | Resolve to original dual logo lockup and clear URL. | Bronze shape expands to final field; white URL rises through a mask; hold at least 2 seconds. | Resolve harmony; controlled decay, no abrupt audio end. |

## 8-second approval prototype
A self-contained motion sample demonstrates the visual and audio system before the full film:
- 0.00–1.80: cream editorial hook, original logos, staggered type masks and bronze line.
- 1.60–4.00: line grows into a rounded browser frame; real homepage is revealed; title counter-moves.
- 3.75–6.25: browser composition transforms into a three-image gallery; independent panel motion, family labels and new headline.
- 6.00–8.00: bronze circle expands into the closing field, dual logo plate and masked website URL resolve.

Cubic Bézier curves vary across text and frames; high-speed panels include restrained directional ghosting. Transition overlaps: 0.25–0.5 seconds. No simple fade-driven slideshow. Music and effects are synthesized specifically for this prototype at 120 BPM, with scene changes on beat boundaries. No third-party commercial music recording is used. Final-film soundtrack direction remains reviewable.

## Approval and deliverables
Deliver this prototype with editable React / TypeScript / Remotion source, original synthesized WAV and render commands. The supplied brief requires prototype approval before full production; that approval has now been received. The prototype was approved in chat; the full 20-second film is now produced in the same visual and sound direction. Vertical recomposition is optional and is not included in this 16:9 prototype.
