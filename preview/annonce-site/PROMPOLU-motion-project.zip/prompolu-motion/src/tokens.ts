export const T = {paper:'#F1F0EC',ink:'#15171A',bronze:'#8C6A45',light:'#D7C6AF',fps:60,duration:480,width:3840,height:2160};
