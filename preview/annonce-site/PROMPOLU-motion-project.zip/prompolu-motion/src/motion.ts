import {Easing, interpolate} from 'remotion';
export const smooth=Easing.bezier(.22,1,.36,1);
export const cinematic=Easing.bezier(.76,0,.24,1);
export const fast=Easing.bezier(.16,1,.3,1);
export const progress=(f:number,a:number,b:number,e=smooth)=>interpolate(f,[a,b],[0,1],{easing:e,extrapolateLeft:'clamp',extrapolateRight:'clamp'});
export const mix=(a:number,b:number,p:number)=>a+(b-a)*p;
