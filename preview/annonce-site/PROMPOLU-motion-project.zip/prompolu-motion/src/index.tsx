import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Film} from './Film';
import {T} from './tokens';
import {LaunchFilm} from './LaunchFilm';
const Root:React.FC=()=> <><Composition id="PrompoluPrototype" component={Film} durationInFrames={T.duration} fps={T.fps} width={T.width} height={T.height}/><Composition id="PrompoluLaunch" component={LaunchFilm} durationInFrames={1200} fps={60} width={3840} height={2160}/></>;
registerRoot(Root);
