# PROMPOLU motion announcement — full film and approved prototype

20-second horizontal launch film, plus the approved 8-second prototype. Both: 3840 × 2160, 60 fps, H.264 / yuv420p, AAC 48 kHz stereo.

Read CREATIVE-DIRECTION.md for reference limitations, original art direction, the proposed 20-second storyboard, beat map, asset provenance and approval boundary. The 20-second film follows approval of the 8-second prototype. French, instrumental, no voice-over. No reference video was attached.

## Files
- src/Film.tsx — approved prototype and shared logo / typography components.
- src/LaunchFilm.tsx — complete 20-second launch film.
- TIMELINE.json — scene assets, compositions, timings, easing, sound cues and implementation.
- src/motion.ts — Bézier easing and interpolation helpers.
- src/tokens.ts — colour, resolution, frame rate and duration.
- public/assets — original logos, website fonts, captured website UI and existing illustrative site images.
- public/soundtrack.wav and public/launch-soundtrack.wav — original synthesized music and synchronized effects, without third-party samples.
- scripts/soundtrack.py — reproducible soundtrack generation (Python 3 + NumPy).
- scripts/render.cjs — still and video renderer using the system Chromium installation.
- scripts/export.cjs — FFmpeg delivery encodes, BT.709 limited range / yuv420p and fast-start MP4.
- output/PROMPOLU-launch-4K.mp4 — complete film master.
- output/PROMPOLU-launch-1080p.mp4 — complete film review copy.
- output/PROMPOLU-prototype-4K.mp4 — approved prototype.
- output/PROMPOLU-prototype-1080p.mp4 — lightweight review copy.

## Setup and rendering
Use Node.js 22+, npm, FFmpeg 7+, Python 3 + NumPy and Chromium. On the prepared machine, Chromium is /usr/bin/chromium. Change browserExecutable in scripts/render.cjs when using another system.

```sh
cd /workspace/prompolu-motion
npm ci --cache /workspace/.npm-cache
npx tsc --noEmit
node scripts/render.cjs --full --stills
node scripts/render.cjs --full
# For the original prototype, omit --full.
```

To regenerate the soundtrack:

```sh
python scripts/soundtrack.py --full
ffmpeg -y -i public/launch-soundtrack-raw.wav -af loudnorm=I=-16:TP=-1.5:LRA=8 -ar 48000 public/launch-soundtrack.wav
```

Music is generated for this project from oscillators and procedural noise. The source contains no third-party recordings; use of the original logos and supplied visual assets remains under the website owner's existing rights.

The prototype was approved in chat. The full film is supplied on the existing unlisted / noindex video preview page; the marketing website navigation is unchanged. No social-media posting is performed.
