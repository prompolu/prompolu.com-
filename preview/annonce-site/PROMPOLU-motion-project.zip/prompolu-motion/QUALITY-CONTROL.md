# Full-film export validation

The approved prototype has been expanded into the complete 20-second film.

- 20.000 seconds, 1,200 decoded frames at 60 fps.
- 3840 × 2160 H.264, yuv420p, BT.709 limited range.
- AAC stereo, 48 kHz; measured −16.0 LUFS; true peak −2.3 dBFS.
- No uniform blank decoded frames, full-frame black intervals, or silence longer than 0.2 seconds at −45 dBFS.
- Original logo files verified byte-for-byte against the website repository.
- TypeScript check passed. Scene states and encoded scene boundaries visually inspected.
- All four product families are featured. Existing images retain their proportions. The exterior technical render is labelled illustration 3D.
- The quote interface is the actual website form, with a real product reference and no form submission or outgoing message.
- Final website address holds in its resolved position for more than two seconds.
- 4K and 1080p files are below the hosting service's 25 MiB per-file limit.
- Both the approved prototype and complete film are available on the unlisted / noindex preview page. No social-media publication is performed.

No reference video was attached. Art direction follows the user's written principles and the approved prototype.
