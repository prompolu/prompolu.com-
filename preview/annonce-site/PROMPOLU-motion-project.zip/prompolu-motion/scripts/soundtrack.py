"""Original 120 BPM electronic bed and frame-synchronised effects. No samples."""
import numpy as np,wave,sys
from pathlib import Path
full='--full' in sys.argv
sr=48000;duration=20 if full else 8;n=sr*duration;t=np.arange(n)/sr
rng=np.random.default_rng(21);mix=np.zeros((n,2))
def add(signal,start,amp=1,pan=0):
 a=int(start*sr);z=min(len(signal),n-a)
 if z<=0:return
 mix[a:a+z,0]+=signal[:z]*amp*np.sqrt((1-pan)/2)
 mix[a:a+z,1]+=signal[:z]*amp*np.sqrt((1+pan)/2)
def tone(freq,length,attack=.02,decay=.7):
 x=np.arange(int(sr*length))/sr;env=np.minimum(x/attack,1)*np.exp(-x/decay)
 return x,env
# Warm four-chord harmonic bed; distinct stereo voices, soft attacks.
chords=[[220,261.6256,329.6276],[174.6141,220,261.6256],[130.8128,164.8138,195.9977],[195.9977,246.9417,293.6648]]
for j in range(duration//2):
 chord=chords[j%4]
 for k,freq in enumerate(chord):
  x,e=tone(freq,2.8,.32,2.2);release=np.minimum((2.8-x)/.7,1)
  pad=(np.sin(2*np.pi*freq*x)+.22*np.sin(2*np.pi*(freq*2+.3)*x))*.045*e*release
  add(pad,j*2,pan=(-.35,.1,.35)[k])
# Restrained quarter-note kick and sub; 16 beats.
for beat in range(duration*2):
 x=np.arange(int(.30*sr))/sr
 phase=2*np.pi*(46*x+65*.025*(1-np.exp(-x/.025)))
 kick=np.sin(phase)*np.exp(-x*17)*np.minimum(x/.003,1)
 add(kick,beat*.5,.15)
 # Light offbeat hats: differentiated noise, no licensed sample.
 x=np.arange(int(.07*sr))/sr;noise=rng.normal(0,1,len(x));noise=np.r_[0,np.diff(noise)]
 hat=noise*np.exp(-x*85)*np.minimum(x/.002,1)
 add(hat,beat*.5+.25,.009,pan=(-.35 if beat%2 else .35))
 # Sparse tonal plucks follow harmony.
 if beat%2:
  freq=[659.255,523.251,783.991,587.33][(beat//4)%4];x,e=tone(freq,.65,.004,.12)
  add(np.sin(2*np.pi*freq*x)*e,beat*.5,.035,pan=.2)
# Air transitions: opening frame, gallery, final bronze reveal.
sweeps=[(1.75,.45,-.3),(4.75,.4,.35),(8.75,.4,-.35),(11.75,.45,.3),(16,.5,0)] if full else [(1.5,.45,-.3),(3.75,.38,.35),(6,.5,0)]
for at,length,pan in sweeps:
 x=np.arange(int(length*sr))/sr;noise=rng.normal(0,1,len(x));smooth=np.convolve(noise,np.ones(45)/45,mode='same')
 env=np.sin(np.pi*x/length)**2
 add(smooth*env,at,.095,pan)
# UI micro-clicks at mask/card landings.
for at in ([.5,1,2,5.5,6,9.5,10,12,13,14,16.5,17] if full else [.5,1,2,4.25,4.5,4.75,6.5]):
 x=np.arange(int(.07*sr))/sr
 add((np.sin(2*np.pi*1400*x)+.4*np.sin(2*np.pi*2150*x))*np.exp(-x*110),at,.017,pan=.2)
# Natural short reflections; no hard cutoff at the end.
dry=mix.copy()
for delay,gain in [(.125,.13),(.25,.08),(.375,.04)]:
 d=int(delay*sr);mix[d:]+=dry[:-d,::-1]*gain
fade=np.minimum(t/.07,1)*np.minimum((duration-t)/.3,1);mix*=fade[:,None]
mix*=.78/max(np.max(np.abs(mix)),.001)
out=Path(__file__).resolve().parents[1]/'public'/('launch-soundtrack-raw.wav' if full else 'soundtrack-raw.wav')
with wave.open(str(out),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
print(out)
