const {spawnSync}=require('child_process');const path=require('path');const root=path.resolve(__dirname,'..');
function ffmpeg(args){const p=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-y',...args],{stdio:'inherit'});if(p.status!==0)throw Error('FFmpeg export failed: '+p.status)}
const input=process.argv[2]||path.join(root,'output/PROMPOLU-prototype-render.mp4');
const prefix=process.argv[3]||'PROMPOLU-prototype';
const master=path.join(root,`output/${prefix}-4K.mp4`);
ffmpeg(['-i',input,'-vf','scale=in_range=full:out_range=tv,format=yuv420p,setsar=1','-c:v','libx264','-preset','medium','-crf','17','-threads','4','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','copy','-movflags','+faststart',master]);
ffmpeg(['-i',master,'-vf','scale=1920:1080:flags=lanczos,format=yuv420p','-c:v','libx264','-preset','medium','-crf','19','-threads','4','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','copy','-movflags','+faststart',path.join(root,`output/${prefix}-1080p.mp4`)]);
console.log('Delivery exports complete: 4K and 1080p, limited-range BT.709 / yuv420p');
