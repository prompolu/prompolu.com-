from pathlib import Path
import json,subprocess,re,hashlib,zipfile
r=Path(__file__).resolve().parents[1];out=r/'output';master=out/'PROMPOLU-launch-4K.mp4';review=out/'PROMPOLU-launch-1080p.mp4'
def command(args):return subprocess.check_output(args,text=True)
info=json.loads(command(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,r_frame_rate,pix_fmt,color_range,color_space,sample_rate,channels,nb_frames','-show_entries','format=duration','-of','json',str(master)]));(out/'launch-technical-validation.json').write_text(json.dumps(info,indent=2))
v,a=info['streams'];assert(v['width'],v['height'])==(3840,2160);assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='60/1' and int(v['nb_frames'])==1200;assert a['codec_name']=='aac' and a['sample_rate']=='48000' and a['channels']==2;assert abs(float(info['format']['duration'])-20)<.02
qc=out/'launch-quality-control.log'
with qc.open('w') as f:
 subprocess.run(['ffmpeg','-hide_banner','-i',str(master),'-vf','blackdetect=d=0.05:pic_th=0.98:pix_th=0.05','-af','silencedetect=noise=-45dB:d=0.2,ebur128=peak=true','-f','null','-'],stderr=f,stdout=f,check=True)
log=qc.read_text();assert 'black_start:' not in log;assert 'silence_start:' not in log
stats=out/'launch-frame-signalstats.log'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(review),'-vf',f'signalstats,metadata=print:file={stats}','-an','-f','null','-'],check=True)
s=stats.read_text();mins=[float(x) for x in re.findall(r'lavfi.signalstats.YMIN=([\d.]+)',s)];maxs=[float(x) for x in re.findall(r'lavfi.signalstats.YMAX=([\d.]+)',s)];assert len(mins)==1200;assert all(b-a>30 for a,b in zip(mins,maxs))
for name in ['logo-prompolu.png','logo-strugal.png']:
 assert hashlib.sha256((r/'public/assets'/name).read_bytes()).digest()==hashlib.sha256((Path('/workspace/prompolu.com-/assets')/name).read_bytes()).digest()
for file in [master,review]:assert file.stat().st_size<25*1024*1024,file
print('PASS full film: 20 seconds / 1200 frames; expected codecs; no uniform blank or black frames; no extended silence; logos unchanged; delivery files below 25 MiB')
print(log[log.rfind('Integrated loudness:'):])
